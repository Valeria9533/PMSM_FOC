#include "lib.h"

extern float power_fault,power_over,power_max,power_nominal,power_min,omega_max,omega_ramp,i_sdq_max,i_sdq_max_cont,i_sd_alignment,i_sd_fault;
extern float pi_p_gain_omega, pi_i_gain_omega, pi_p_gain_is, pi_i_gain_is;
extern float scale_power, scale_omega, scale_current, U_desired;
extern dq_System  i_Sdq_filt;

float sin_table[361];
float cos_table[361];

float err_int=0, err_max = INT16_MAX;

// Voltage variables
ABC_System u_Sabc; // stator voltage in a,b,c	
ab_System  u_SAlphaBeta; // stator voltage in alfa,beta
dq_System  u_Sdq;	 // stator voltage in d,q
dq_System  u_Sdq_filt;

// Current variables
ABC_System i_Sabc_adc; // ADC current measurements in a,b,c
ABC_System i_Sabc; // stator current in a,b,c	
ab_System  i_SAlphaBeta; // stator current in alfa,beta
dq_System  i_Sdq;	 // stator current in d,q
dq_System  i_Sdq_desired = {0, 0}; // desired stator current d,q coordinates

// PI parameters
PI_params  omega_PI_params; 
PI_params  current_PI_params; 

void Park(ab_System *p_alphaBeta, dq_System *p_dq, int16_t theta_el) { // ab->dq

	p_dq->d_axis = p_alphaBeta->a_axis*cos_table[theta_el] + p_alphaBeta->b_axis*sin_table[theta_el];

	if (p_dq->d_axis > 32767) p_dq->d_axis = 32767;
  else if (p_dq->d_axis < -32767) p_dq->d_axis = -32767;
	
	p_dq->q_axis = -p_alphaBeta->a_axis*sin_table[theta_el] + p_alphaBeta->b_axis*cos_table[theta_el];
	
	if (p_dq->q_axis > 32767) p_dq->q_axis = 32767;
  else if (p_dq->q_axis < -32767) p_dq->q_axis = -32767;
}

void invPark(ab_System *p_alphaBeta, dq_System *p_dq, int16_t theta_el) { // dq->ab
		
	p_alphaBeta->a_axis = p_dq->d_axis*cos_table[theta_el] - p_dq->q_axis*sin_table[theta_el];
	
	if (p_alphaBeta->a_axis > 32767) p_alphaBeta->a_axis = 32767;
  else if (p_alphaBeta->a_axis < -32767) p_alphaBeta->a_axis = -32767;
	
	p_alphaBeta->b_axis = p_dq->d_axis*sin_table[theta_el] + p_dq->q_axis*cos_table[theta_el];
	
	if (p_alphaBeta->b_axis > 32767) p_alphaBeta->b_axis = 32767;
  else if (p_alphaBeta->b_axis < -32767) p_alphaBeta->b_axis = -32767;
}

void Clarke(ab_System *p_alphaBeta, ABC_System *p_abc) { // abc->ab
	
	p_alphaBeta->a_axis = 0.667*(p_abc->phaseA - 0.5*p_abc->phaseB - 0.5*p_abc->phaseC);
	
	if (p_alphaBeta->a_axis > 32767) p_alphaBeta->a_axis = 32767;
  else if (p_alphaBeta->a_axis < -32767) p_alphaBeta->a_axis = -32767;
	
	p_alphaBeta->b_axis = 0.667*(0.866*p_abc->phaseB - 0.866*p_abc->phaseC);
	
	if (p_alphaBeta->b_axis > 32767) p_alphaBeta->b_axis = 32767;
  else if (p_alphaBeta->b_axis < -32767) p_alphaBeta->b_axis = -32767;
}

float PI_reg(float act_val, float des_val, PI_params* pi_params) {
	 
	float err_curr=0, out=0;
	
	err_curr = des_val - act_val;
	err_int += err_curr;
	
	/* Limiting error */
	if (err_int < -err_max) 
		err_int = -err_max;
	else if (err_int > err_max) 
		err_int = err_max;

	out = pi_params->K_p*err_curr + pi_params->K_i*err_int;

	/* Limiting output */
  if (out < pi_params->pi_out_min) 
		out = pi_params->pi_out_min;
  else if (out > pi_params->pi_out_max) 
		out = pi_params->pi_out_max;

  return(out);
}

void SVPWM(ab_System *p_alphaBeta) {
		
	U_ref = sqrt(p_alphaBeta->a_axis*p_alphaBeta->a_axis + p_alphaBeta->b_axis*p_alphaBeta->b_axis);
	
	if (U_ref > power*2/1.73205) U_ref = power*2/1.73205; // power*2/sqrt(3);
	
	U_ref_angle = p_alphaBeta->b_axis/p_alphaBeta->a_axis; // tan(U_ref_angle)
	
	/* Sectors 1,4 */
	if((U_ref_angle >= 0.0) && (U_ref_angle < 1.7321)) 
	{
		if((p_alphaBeta->a_axis > 0) && (p_alphaBeta->b_axis > 0)) {
			t1 = fabs((p_alphaBeta->a_axis - p_alphaBeta->b_axis*0.57735)/(0.8165*power)); // V1 // 0.8165 = sqrt(2/3)
			t2 = fabs(p_alphaBeta->b_axis*1.1547/(0.8165*power)); // V2
			
			if(t1>1) t1=1; if(t2>1) t2=1; 
			
			if(((uint8_t)(t1*100)+(uint8_t)(t2*100)) > 100) {
				t1 = t1/(t1+t2);
				t2 = t2/(t1+t2);
			}
			
			t0 = fabs(1 - t1 - t2); // V0
						
			switch_time_A = t1 + t2 + t0/2; 
			switch_time_B = t2 + t0/2;
			switch_time_C = t0/2;
						
			sector = 1;
		}
		else if((p_alphaBeta->a_axis < 0) && (p_alphaBeta->b_axis < 0)) {
			t1 = fabs((-p_alphaBeta->a_axis + p_alphaBeta->b_axis*0.57735)/(0.8165*power)); // V4
			t2 = fabs(-p_alphaBeta->b_axis*1.1547/(0.8165*power)); // V5
			
			if(t1>1) t1=1; if(t2>1) t2=1; 
			
			if(((uint8_t)(t1*100)+(uint8_t)(t2*100)) > 100) {
				t1 = t1/(t1+t2);
				t2 = t2/(t1+t2);
			}
			
			t0 = fabs(1 - t1 - t2); // V0
			
			switch_time_A = t0/2;
			switch_time_B = t1 + t0/2;
			switch_time_C = t1 + t2 + t0/2;
			
			sector = 4;
		}
	}
	
	/* Sectors 2,5 */
	else if((U_ref_angle >= 1.7321) && (U_ref_angle <= 57.29) || (U_ref_angle >= -57.29 ) && (U_ref_angle < -1.7321)) 
	{
		if(p_alphaBeta->b_axis > 0) { 
			t1 = fabs((p_alphaBeta->a_axis + 0.5*p_alphaBeta->b_axis*1.1547)/(0.8165*power)); // V2
			t2 = fabs((-p_alphaBeta->a_axis + 0.5*p_alphaBeta->b_axis*1.1547)/(0.8165*power)); // V3
			
			if(t1>1) t1=1; if(t2>1) t2=1; 
			
			if(((uint8_t)(t1*100)+(uint8_t)(t2*100)) > 100) {
				t1 = t1/(t1+t2);
				t2 = t2/(t1+t2);
			}
			
			t0 = fabs(1 - t1 - t2); // V0
			
			switch_time_A = t1 + t0/2;
			switch_time_B = t1 + t2 + t0/2;
			switch_time_C = t0/2;
			
			sector = 2;
		}
		else if(p_alphaBeta->b_axis < 0) {
			t1 = fabs((-p_alphaBeta->a_axis - 0.5*p_alphaBeta->b_axis*1.1547)/(0.8165*power)); // V5
			t2 = fabs((p_alphaBeta->a_axis - 0.5*p_alphaBeta->b_axis*1.1547)/(0.8165*power)); // V6
			
			if(t1>1) t1=1; if(t2>1) t2=1; 
			
			if(((uint8_t)(t1*100)+(uint8_t)(t2*100)) > 100) {
				t1 = t1/(t1+t2);
				t2 = t2/(t1+t2);
			}
			
			t0 = fabs(1 - t1 - t2); // V0
			
			switch_time_A = t2 + t0/2;
			switch_time_B = t0/2;
			switch_time_C = t1 + t2 + t0/2;
			
			sector = 5;
		}
	}
	
	/* Sectors 3,6 */
	else if((U_ref_angle >= -1.7321) && (U_ref_angle < 0))
	{
		if((p_alphaBeta->a_axis < 0) && (p_alphaBeta->b_axis > 0)) {
			t1 = fabs(p_alphaBeta->b_axis*1.1547/(0.8165*power)); // V3
			t2 = fabs((-p_alphaBeta->a_axis - p_alphaBeta->b_axis*0.57735)/(0.8165*power)); // V4
			
			if(t1>1) t1=1; if(t2>1) t2=1; 
			
			if(((uint8_t)(t1*100)+(uint8_t)(t2*100)) > 100) {
				t1 = t1/(t1+t2);
				t2 = t2/(t1+t2);
			}
			
			t0 = fabs(1 - t1 - t2); // V0
			
			switch_time_A = t0/2;
			switch_time_B = t1 + t2 + t0/2;
			switch_time_C = t2 + t0/2;
			
			sector = 3;
		}
		else if((p_alphaBeta->a_axis > 0) && (p_alphaBeta->b_axis < 0)) {
			t1 = fabs((p_alphaBeta->a_axis - p_alphaBeta->b_axis*0.57735)/(0.8165*power)); // V6
			t2 = fabs(-p_alphaBeta->b_axis*1.1547/(0.8165*power)); // V1
			
			if(t1>1) t1=1; if(t2>1) t2=1; 
			
			if(((uint8_t)(t1*100)+(uint8_t)(t2*100)) > 100) {
				t1 = t1/(t1+t2);
				t2 = t2/(t1+t2);
			}
			
			t0 = fabs(1 - t1 - t2); // V0
			
			switch_time_A = t1 + t2 + t0/2;
			switch_time_B = t0/2;
			switch_time_C = t1 + t0/2;
			
			sector = 6;
		}
	}

	else {}
	
	TIM1->CCR1 = switch_time_A*TIM1->ARR;
	TIM1->CCR2 = switch_time_B*TIM1->ARR;
	TIM1->CCR3 = switch_time_C*TIM1->ARR;
}

void PWM_Enable(void) {
	
	TIM1->CCER |= 0x1555;	
	TIM1->BDTR |= TIM_BDTR_MOE;
}	

void PWM_Disable(void) {	
	
	TIM1->CCER &= ~0x1555;
	TIM1->BDTR |= TIM_BDTR_MOE;	

	U_desired = 0;
	i_Sdq_desired.d_axis = i_Sdq_desired.q_axis = 0;
	u_Sdq.d_axis = u_Sdq.q_axis = 0;
	u_Sabc.phaseA = u_Sabc.phaseB = u_Sabc.phaseC = TIM1->ARR>>1;
	sector = 1;
}	
