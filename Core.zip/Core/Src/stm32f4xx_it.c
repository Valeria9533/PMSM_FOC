/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lib.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */
extern ABC_System u_Sabc; 
extern ab_System  u_SAlphaBeta;
extern dq_System  u_Sdq;	
extern dq_System  u_Sdq_filt;
extern ABC_System i_Sabc_adc; 
extern ABC_System i_Sabc; 
extern dq_System  i_Sdq;
extern ab_System  i_SAlphaBeta;
extern dq_System  i_Sdq_desired;
extern dq_System  i_Sdq_filt; 
extern PI_params  omega_PI_params;
extern PI_params  current_PI_params;
/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
extern float U_desired, omega_desired, omega_actual;
extern int16_t Command;
extern uint8_t overcurrent, overvolt, undervolt, overload, status_flag, sensor_fault, hall_table[8]; 
uint16_t Enc_in, Enc_out, adc_event=0, tim1_event=0, while1_event=0, tim7_event=0, sysTick_event=0, adc_cnt=1000, tim7_cnt=0, tim7_cnt1=0;
uint8_t sector, adc_init=0, hall_state, hall_state_old, ii=0, j=0;
int32_t uwTick_old = 0;
int16_t delta_enc, delta_enc_filt=0, delta_enc_arr[10], TIM1_ADC_1_S, TIM1_ADC_1_E, TIM1_ADC_2_S, TIM1_ADC_2_E, TIM1_ADC_1, TIM1_ADC_2;
float dtime, dhall, tim1_tick1, tim1_tick2, omega_actual_filt=0, omega_actual_filt1=0, omega_act, adc[3] = {0,0,0};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
void Control_PWM_1(void); 
void ADC_callback_1(void);
void ADC_read(void);
void Get_speed_encoder(uint16_t input);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;
extern ADC_HandleTypeDef hadc3;
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim7;
/* USER CODE BEGIN EV */
extern float power_fault,power_over,power_max,power_nominal,power_min,omega_max,omega_ramp,i_sdq_max,i_sdq_max_cont,i_sd_alignment,i_sd_fault;
extern float scale_power, scale_omega, scale_current;
extern float pi_p_gain_omega, pi_i_gain_omega, pi_p_gain_is, pi_i_gain_is, err_int_q_is, err_int_d_is;
/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
  while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */
	sysTick_event++;
	
  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */
	
  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles ADC1, ADC2 and ADC3 global interrupts.
  */
void ADC_IRQHandler(void)
{
  /* USER CODE BEGIN ADC_IRQn 0 */
  ADC1->SR = 0;
	adc_event++;
  /* USER CODE END ADC_IRQn 0 */
  /* USER CODE BEGIN ADC_IRQn 1 */
	if (TIM1->CNT > (TIM1->ARR>>1)) 
		ADC_callback_1();
	//else 
	//	ADC_callback_2();
  /* USER CODE END ADC_IRQn 1 */
}

/**
  * @brief This function handles TIM1 update interrupt and TIM10 global interrupt.
  */
void TIM1_UP_TIM10_IRQHandler(void)
{
  /* USER CODE BEGIN TIM1_UP_TIM10_IRQn 0 */
	TIM1->SR = 0;
	tim1_event++;
		
  /* USER CODE END TIM1_UP_TIM10_IRQn 0 */
  /* USER CODE BEGIN TIM1_UP_TIM10_IRQn 1 */
	
	hall_state = ((H1_GPIO_Port->IDR)>>6)&7;
	
	if ((hall_state > 0) && (hall_state < 7)) sensor_fault = 0; 		
	else sensor_fault = 1;
	
	//Get_speed_Hall();
  /* USER CODE END TIM1_UP_TIM10_IRQn 1 */
}

/**
  * @brief This function handles TIM7 global interrupt.
  */
void TIM7_IRQHandler(void)
{
  /* USER CODE BEGIN TIM7_IRQn 0 */
	TIM7->SR = 0;
  /* USER CODE END TIM7_IRQn 0 */
  /* USER CODE BEGIN TIM7_IRQn 1 */

	tim7_event++;	
	tim7_cnt++;
	tim7_cnt1++;
	
	status_flag = overcurrent+overvolt+undervolt+overload+sensor_fault;	
		
	if(status_flag != 0) GPIOD->ODR &= ~(1<<4); // error led
	else GPIOD->ODR |= (1<<4);
	
	if ((status_flag == 0)&&(Command != 'h')) {
		PWM_Enable(); 
	}
	else { 
		PWM_Disable(); 
		Command = 'h';		
	}		
	
	if(tim7_cnt == 500) {
		GPIOD->ODR ^= (1<<2); // power_on led
		tim7_cnt = 0;
	}
	
	if(tim7_cnt1 == 50) {
		Get_speed_encoder(Enc_in); 
		tim7_cnt1 = 0;		
	}
  /* USER CODE END TIM7_IRQn 1 */
}

/* USER CODE BEGIN 1 */
void Control_PWM_1(void) {
	
	static int16_t t_i;
	
	//------------------------------------------------ Update PI parameters ------------------------------------------------//
	current_PI_params.K_p = pi_p_gain_is;
	current_PI_params.K_i = pi_i_gain_is;
	current_PI_params.pi_out_max = i_sdq_max;
	current_PI_params.pi_out_min = -i_sdq_max;
	
	omega_PI_params.K_p = pi_p_gain_omega;
	omega_PI_params.K_i = pi_i_gain_omega;
	omega_PI_params.pi_out_max = i_sdq_max;
	omega_PI_params.pi_out_min = -i_sdq_max;
	
	//------------------------------------------------------- Stop ---------------------------------------------------------//
	if (Command == 'h') PWM_Disable();
	
	//-------------------------------------------------- Set current loop --------------------------------------------------//
	if (Command == 'i') {	
		step = 0;
		if (((t_i++) & 0x20) != 0) i_Sdq_desired.q_axis = i_sd_alignment;
		else i_Sdq_desired.q_axis = 0;
	}	
	
	//--------------------------------------------------- Torque control ---------------------------------------------------//
	if ((Command == 'n') && (dir_step != 0)) {		
	
		step += dir_step;

		if(dir_step > 0) {
			if(step >= INT16_MAX) step = 0;	
		}			
		else {
			if(step <= -INT16_MAX) step = 0;
		}

		theta_el_deg = abs(step)*360/INT16_MAX; 		
		GPIOD->ODR &= ~(1<<3); // run led
	}
	
	//----------------------------------------------------------------------------------------------------------------------//
	
	if ((Command != 'h') && (status_flag == 0)) {
		PWM_Enable();
	}
	
	//--------------------------------------------------- Speed control ----------------------------------------------------//
	if (Command == 'o') {		
		
		theta_el_deg = Enc_in*360*15/INT16_MAX;	// 0-5400
		
		GPIOD->ODR &= ~(1<<3); // run led
		
		if (omega_desired > omega_max) omega_desired = omega_max; 
		if (omega_desired < -omega_max) omega_desired = -omega_max;
		
		//U_required = PI_reg(omega_actual, omega_desired, &omega_PI_params);			

		i_Sdq_desired.q_axis = PI_reg(omega_actual, omega_desired, &omega_PI_params);	
	}
	
	//----------------------------------------------------------------------------------------------------------------------//

	Clarke(&i_SAlphaBeta, &i_Sabc); 
		
	Park(&i_SAlphaBeta, &i_Sdq, theta_el_deg); 

	// Set current integral errors for each axis
	current_PI_params.err_int = err_int_q_is; 
	u_Sdq.q_axis = PI_reg(i_Sdq.q_axis, i_Sdq_desired.q_axis, &current_PI_params);
	err_int_q_is = current_PI_params.err_int;
	
	current_PI_params.err_int = err_int_d_is; 
	u_Sdq.d_axis = PI_reg(i_Sdq.d_axis, 0, &current_PI_params);
	err_int_d_is = current_PI_params.err_int;
	
	//----------------------------------------------------------------------------------------------------------------------//

	invPark(&u_SAlphaBeta, &u_Sdq, theta_el_deg);
		
	SVPWM(&u_SAlphaBeta);		
}

void ADC_callback_1(void) {
	
	static int16_t adc_delay = 16000;	
	
	TIM1_ADC_1_S = TIM1->CNT;
	
	// Send request to abs encoder
	SPI2_NSS_SET;
	SPI2->DR = 0xAAAA;
	
	// Read answer from abs encoder
	Enc_in = SPI2->DR-32767;
	
	if (adc_delay == 0) {
		ADC_read();
	}
	else adc_delay--;
	
	if(adc_init == 1) {
		// Check faults
		if (__HAL_TIM_GET_FLAG(&htim1, TIM_FLAG_BREAK)==SET) { 
			overcurrent = 1;
		  PWM_Disable(); 
			Command = 'h';
		}
		else overcurrent = 0;
		
		// Check power
		if (power > power_fault) overvolt = 1;
		else overvolt = 0;
		if (power < power_min) undervolt = 1; 
		else undervolt = 0; 
		
		// Limit current
		if (i_Sdq_desired.q_axis > i_sdq_max) i_Sdq_desired.q_axis = i_sdq_max;
		if (i_Sdq_desired.q_axis < -i_sdq_max) i_Sdq_desired.q_axis = -i_sdq_max;	

		Control_PWM_1();	
	}
	else { 
		// Reset fault while power up
		__HAL_TIM_CLEAR_FLAG(&htim1, TIM_FLAG_BREAK);				
	}
	
	FMSTR_Recorder();
	
	TIM1_ADC_1_E = TIM1->CNT;
	
	TIM1_ADC_1 = abs(TIM1_ADC_1_E - TIM1_ADC_1_S);
}

void ADC_read(void) {
	
	// Reading ADC
	i_Sabc_adc.phaseA = ADC1->JDR1;
	i_Sabc_adc.phaseB = ADC2->JDR1;
	i_Sabc_adc.phaseC = ADC3->JDR2;
	power = ADC3->JDR1;

	if(adc_init == 0) {
		if (adc_cnt <= 0) {
			adc[0]=adc[0]/1000;	
			adc[1]=adc[1]/1000;
			adc[2]=adc[2]/1000;		
			adc_init = 1;		
		} 
		else {
			adc[0]+=i_Sabc_adc.phaseA;	
			adc[1]+=i_Sabc_adc.phaseB;	
			adc[2]+=i_Sabc_adc.phaseC;	
			adc_cnt--;
		}
	}
	else {
		i_Sabc.phaseA=adc[0]-i_Sabc_adc.phaseA;
		i_Sabc.phaseB=adc[1]-i_Sabc_adc.phaseB; 
		i_Sabc.phaseC=adc[2]-i_Sabc_adc.phaseC;
	}
}

void Get_speed_encoder(uint16_t input) {
	
	static uint16_t input_old = 0;	
	
	delta_enc_filt=0;

	if(abs(input - input_old) < 32000) delta_enc = input - input_old; 
	input_old = input;
	
	delta_enc_arr[ii] = delta_enc;
	ii++;
	
	if(ii==20) {
		for(j=0; j<ii; j++){
			delta_enc_filt += delta_enc_arr[j];
		}
		delta_enc_filt /= ii;
		omega_actual = fabs((float)delta_enc_filt*0.23);
		ii=0;
	}
	
	if(delta_enc==0) omega_actual=0;
}

/* USER CODE END 1 */
