#include "main.h"
#include "math.h"
#include "def.h"

/* Defined in main.c */
extern float switch_time_A, switch_time_B, switch_time_C;
extern uint8_t sector;
extern float U_ref, U_ref_percent;
extern float power;
extern float U_ref_angle;
extern float t1, t2, t0, t0_half, ontime_t0_half, ontime_value_1, ontime_value_2, ontime_value_3;
extern int16_t dir_step, theta_el_deg, theta_act;//theta_mech_deg, theta_hall_mech_deg, theta_hall_mech_deg_old, dtheta_hall;
extern int32_t step, theta_mech;

typedef struct {
    float phaseA;
    float phaseB;
    float phaseC;
} ABC_System;

typedef struct {
    float a_axis;
    float b_axis;
} ab_System;

typedef struct {
    float d_axis;
    float q_axis;
} dq_System;

typedef struct {
		float K_p; 
    float K_i;			
    float pi_out_max;	
    float pi_out_min;	
		float err_int;
} PI_params;

void Park(ab_System *p_alphaBeta, dq_System *p_dq, int16_t theta_el);
void invPark(ab_System *p_alphaBeta, dq_System *p_dq, int16_t theta_el);
void Clarke(ab_System *p_alphaBeta, ABC_System *p_abc);
void SVPWM(ab_System *p_alphaBeta);
float PI_reg(float act_val, float des_val, PI_params* pi_params);
void PWM_Enable(void);
void PWM_Disable(void);
