
#define FRAC32(x) ((int32_t)((x) < 1 ? ((x) >= -1 ? ((int32_t)((x)*0x80000000)) : ((int32_t)0x80000000)) : ((int32_t)0x7FFFFFFF)))

#define PI 3.14159265359

/* power */
#define SCALE_POWER			8860467.2
#define POWER_FAULT			FRAC32(70.0/SCALE_POWER)
#define POWER_OVER			FRAC32(60.0/SCALE_POWER) 
#define POWER_MAX				FRAC32(55.0/SCALE_POWER)   
#define POWER_NOMINAL		FRAC32(48.0/SCALE_POWER) 
#define POWER_MIN				FRAC32(18.0/SCALE_POWER)  

/* speed */
#define SCALE_OMEGA			262144000
#define OMEGA_MAX	 			FRAC32(2000.0/SCALE_OMEGA) // maximal required speed
#define OMEGA_RAMP 			(OMEGA_MAX / 1000.0 + 0.5) // maximal ramp for speed 
#define PI_P_GAIN_OMEGA 0 		// omega PI regulator proportional gain
#define PI_I_GAIN_OMEGA 0 		// omega PI regulator integral gain

/* current */
#define SCALE_CURRENT		10813440
#define I_SDQ_MAX				FRAC32(10.0/SCALE_CURRENT) // maximal current vector 
#define I_SDQ_MAX_CONT	FRAC32(10.0/SCALE_CURRENT) // maximal current vector 
#define I_SD_ALIGNMENT	FRAC32(5.0/SCALE_CURRENT)
#define I_SD_FAULT			FRAC32(40.0/SCALE_CURRENT) // Fault current
#define PI_P_GAIN_IS    0.75	    // stator current both axes PI regulator proportional gain 
#define PI_I_GAIN_IS    0.01	// stator current both axes PI regulator integral gain 

